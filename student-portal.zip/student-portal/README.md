# ANITS Student Portal

A front-end prototype of a college student portal for **Anil Neerukonda Institute of Technology and Sciences (ANITS)**. Students sign in with a demo ID and can view their attendance, marks, assignments, timetable, notices and profile. It is built with React, React Router and Vite, and uses mock data (no backend).

## Features

| Page | What it does |
| --- | --- |
| **Login** | Sign in with a demo Student ID (any password). Demo IDs can be filled in with one click. |
| **Dashboard** | Summary cards and quick overview of the signed-in student. |
| **Attendance** | Subject-wise attendance with progress bars and Good / Average / Low status. Overall attendance is flagged against the 75% minimum. |
| **Marks** | Internal, assignment, mid-term and end-sem marks, total out of 100, grade, semester GPA, CGPA and top subject. |
| **Assignments** | Filter by All / Pending / Submitted / Overdue and mark assignments as submitted. |
| **Timetable** | Weekly class schedule. |
| **Notices** | College announcements. |
| **Profile** | Student details, with editable fields. |

The layout is responsive: the sidebar becomes a slide-out menu on small screens.

## Tech Stack

- [React 18](https://react.dev/)
- [React Router 6](https://reactrouter.com/)
- [Vite 5](https://vitejs.dev/)
- Plain CSS (`src/index.css`)

## Getting Started

**Prerequisite:** [Node.js](https://nodejs.org) 18 or newer.

```bash
# 1. Go into the project folder (the one containing package.json)
cd student-portal

# 2. Install dependencies
npm install

# 3. Start the dev server
npm run dev
```

Then open the URL shown in the terminal (usually <http://localhost:5173>).

### Other scripts

| Command | Description |
| --- | --- |
| `npm run dev` | Start the development server with hot reload |
| `npm run build` | Create a production build in `dist/` |
| `npm run preview` | Preview the production build locally |

## Demo Login

Enter any of the IDs below with **any password** (the password is not checked in this prototype). IDs are not case-sensitive.

| Student ID | Name | Branch |
| --- | --- | --- |
| STU2026 | Harshini Thella | Computer Science |
| STU2027 | Ravi Teja Kommu | Computer Science |
| STU2028 | Sravani Pydi | Information Technology |
| STU2029 | Karthik Varma Penmetsa | Computer Science |
| STU2030 | Anusha Gandham | Information Technology |
| STU2031 | Mohan Krishna Bolla | Computer Science |

Each student has their own attendance, marks, assignments and profile.

## Project Structure

```
student-portal/
├── index.html
├── package.json
├── vite.config.js
└── src/
    ├── main.jsx                 # App entry: Router + StudentProvider
    ├── App.jsx                  # Routes and shared layout (sidebar + header)
    ├── index.css                # All styles
    ├── components/
    │   ├── Header.jsx
    │   ├── Sidebar.jsx
    │   ├── StatCard.jsx
    │   └── NoticeCard.jsx
    ├── context/
    │   └── StudentContext.jsx   # Login state, logout, profile edits
    ├── data/
    │   └── mockData.js          # All demo data (students, timetable, notices, exams)
    └── pages/
        ├── Login.jsx
        ├── Dashboard.jsx
        ├── Attendance.jsx
        ├── Marks.jsx
        ├── Assignments.jsx
        ├── Timetable.jsx
        ├── Notices.jsx
        └── Profile.jsx
```

## How It Works

- **Mock data:** everything lives in `src/data/mockData.js`. Edit it to add students, change marks, update the timetable or post new notices.
- **Auth:** `StudentContext` checks the entered ID against the mock student list and stores the current ID in `localStorage`. Pages under the shared layout redirect to the login page if nobody is signed in.
- **Persistence:** the signed-in student, profile edits and assignment submissions are saved in the browser's `localStorage`, so they survive a refresh. Clear site data to reset them.
- **Grading scale** (total out of 100): O ≥ 90 (10), A+ ≥ 80 (9), A ≥ 70 (8), B+ ≥ 60 (7), B ≥ 50 (6), otherwise C (5). Semester GPA is the average of the subject grade points.
- **Attendance status:** Good ≥ 85%, Average 75–84%, Low < 75%.

## Customising

- **Add a student:** add an entry to the `students` array in `mockData.js` using the `makeAttendance`, `makeMarks` and `makeAssignments` helpers.
- **Change subjects or class totals:** edit the `subjects` and `classTotals` arrays at the top of `mockData.js`.
- **Change college name:** edit the `college` object in `mockData.js`.

## Limitations

This is a prototype for demonstration only:

- No real authentication; passwords are ignored.
- No backend or database; data is static and browser-local.
- Not suitable for storing real student information.

## Ideas for Next Steps

- Connect to a real API with secure authentication
- Add fee payment and exam hall-ticket pages
- Add charts for marks and attendance trends
- Add unit and end-to-end tests
